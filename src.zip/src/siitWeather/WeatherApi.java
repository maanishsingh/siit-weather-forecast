/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siitWeather;

import com.google.gson.Gson;
import java.io.IOException;
import static java.lang.Thread.sleep;
import java.math.RoundingMode;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import javax.swing.ImageIcon;
import static siitWeather.WeatherUI.lblDate;
import static siitWeather.WeatherUI.lblTime;

/**
 *
 * @author manish
 */
public class WeatherApi {
    public static boolean message = true;
    public static float mintempC;
    public static float maxtempC;
    public static float tempC;
    public static float feel_likes;
    public static float humidity;
    public static float visiblity;
    public static float windSpeed;
    public static float pressure;
    public static String pname;
    public static String weatherType;
    public static String weatherIcon;
    
    public void setWeatherIcon(){
        String path = "/siitWeather/wicons/";
        switch(weatherIcon){
            case "50n":
                path = path+ "50d.png";
                break;
            case "50d":
                path = path+ "50d.png";
                break;
            
            case "15d":
                path = path+ "15d.png";
                break;
            case "15n":
                path = path+ "15d.png";
                break;
                
            case "13d":
                path = path+ "13d.png";
                break;
            case "13n":
                path = path+ "13d.png";
                break;
                
            case "11d":
                path = path+ "11d.png";
                break;
            case "11n":
                path = path+ "11d.png";
                break;
                
            case "10d":
                path = path+"10d.png";
                break;
            case "10n":
                path = path+"10d.png";
                break;
                
            case "9d":
                path = path+ "9d.png";
                break;
            case "9n":
                path = path+"9d.png";
                break;
                
            case "4d":
                path = path+"4d.png";
                break;
            case "4n":
                path = path + "4d.png";
                break;
            case "3d":
                path = path+"3d.png";
                break;
            case "3n":
                path = path+"3d.png";
                break;
            case "2d":
                path = path+"2d.png";
                break;
            case "2n":
                path = path+"2d.png";
                break;
                
            case "1d":
                path = path+"1d.png";

                break;
            case "1n":
                path = path + "1d.png";
                break;
            default:
                path = path+"1d.png";
            
                
        }
        //System.out.println(weatherIcon);
        if("50n".equals(weatherIcon)){
        //ImageIcon wticon = new ImageIcon((getClass().getResource("/siitWeather/rain.png")));
        WeatherUI.lblWTicon.setIcon(new javax.swing.ImageIcon(getClass().getResource(path)));
        
        }
    }
    
    
    public static void setTime() throws InterruptedException{
        
        for(;;){
         Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
        SimpleDateFormat sdfDay = new SimpleDateFormat("E, dd MM");
        String sTime = sdf.format(date);
        String date1 = sdfDay.format(date);
        lblDate.setText(date1);
        lblTime.setText(sTime);
        //System.out.println(date1);
        sleep(1000);
        }
    }
    
    public static void updateWeather(){
        DecimalFormat df = new DecimalFormat("#.#");
        df.setRoundingMode(RoundingMode.CEILING); 
        double temp2 = (double)tempC;
        WeatherUI.lblPlace.setText(pname);
        WeatherUI.lblTemp.setText(""+(df.format(temp2))+"°");
        WeatherUI.lblMaxTemp.setText(""+Math.round(maxtempC)+"°");
        WeatherUI.lblMinTemp.setText(""+Math.round(mintempC)+"°");
        WeatherUI.lblFeelLikes.setText(""+feel_likes+"°");
        WeatherUI.lblWind.setText(""+windSpeed+" km/h");
        WeatherUI.lblVisiblity.setText(""+visiblity);
        WeatherUI.lblPressure.setText(""+pressure);
        WeatherUI.lblType.setText(weatherType);
    }
    
    WeatherApi(int code)  throws IOException, InterruptedException{
        var url = "http://api.openweathermap.org/data/2.5/weather?zip="+code+",in&appid=e118a05b3c5774bc63304477a973c1b0";
        var request = HttpRequest.newBuilder().GET().uri(URI.create(url)).build();
        var client = HttpClient.newBuilder().build();
        var response = client.send(request,HttpResponse.BodyHandlers.ofString());
        int rc = response.statusCode();
        if(rc==200){
            message = false;
        }
       // System.out.println(response.body());
        String rb = response.body();
        
     WeatherData weatherdata = new Gson().fromJson(rb,WeatherData.class);
     
    //System.out.println(weatherdata);
     
     //Float tempK = Float.valueOf(weatherdata.main.temp).floatValue();
     float tempK = weatherdata.main.temp;
     
     tempC = (float) (tempK - 273.15);
     mintempC = (float) (weatherdata.main.temp_min - 273.15);
     maxtempC = (float) (weatherdata.main.temp_max - 273.15);
     feel_likes = (float) (weatherdata.main.feels_like - 273.15);
     humidity = weatherdata.main.humidity;
     visiblity = (float) weatherdata.visibility;
     pname = weatherdata.name;
     pressure = weatherdata.main.pressure;
     windSpeed = weatherdata.wind.speed;
     weatherType = weatherdata.weather.get(0).main;
     weatherIcon = weatherdata.weather.get(0).icon;
     
    // System.out.println(mintempC);
    // System.out.println(maxtempC);
    //System.out.println(tempC);
     updateWeather();
     setWeatherIcon();
       
     //System.out.println(weatherdata.name);
    //System.out.println(weatherdata.weather.get(0).icon);
    }
    
}
