/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package siitWeather;

import java.util.List;

/**
 *
 * @author manish
 */
public class WeatherData {
    Coord coord;
    List<Weather> weather;
    //Weather weather;
    String base;
    Main main;
    double visibility;
    Wind wind;
    Clouds clouds;
    double dt;
    Sys sys;
    int timezone;
    int id;
    String name;
    int cod;

    @Override
    public String toString() {
        return "WeatherData{" + "coord=" + coord + ", weather=" + weather + ", base=" + base + ", main=" + main + ", visibility=" + visibility + ", wind=" + wind + ", clouds=" + clouds + ", dt=" + dt + ", sys=" + sys + ", timezone=" + timezone + ", id=" + id + ", name=" + name + ", cod=" + cod + '}';
    }
    
    

    public static class Coord {
        float lon;
        float lat;

        @Override
        public String toString() {
            return "Coord{" + "lon=" + lon + ", lat=" + lat + '}';
        }
        
        
    }

    public static class Weather {
        int id;
        String main;
        String description;
        String icon;

        @Override
        public String toString() {
            return "Weather{" + "id=" + id + ", main=" + main + ", description=" + description + ", icon=" + icon + '}';
        }
        
        
    }

    public static class Main {
        float temp;
        float feels_like;
        float temp_min;
        float temp_max;
        float pressure;
        float humidity;

        @Override
        public String toString() {
            return "MainTemp{" + "temp=" + temp + ", feels_like=" + feels_like + ", temp_min=" + temp_min + ", temp_max=" + temp_max + ", pressure=" + pressure + ", humidity=" + humidity + '}';
        }
        
        

    }

    public static class Wind {
        float speed;
        float deg;

        @Override
        public String toString() {
            return "Wind{" + "speed=" + speed + ", deg=" + deg + '}';
        }
        
        
    }

    public static class Clouds {
        float all;

        @Override
        public String toString() {
            return "Clouds{" + "all=" + all + '}';
        }
        
        
    }

    public static class Sys {
        int type;
        int id;
        String country;
        double sunrise;
        double sunset;

        @Override
        public String toString() {
            return "Sys{" + "type=" + type + ", id=" + id + ", country=" + country + ", sunrise=" + sunrise + ", sunset=" + sunset + '}';
        }
        
        
        
    }
    
}
